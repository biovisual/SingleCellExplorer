import os, sys, csv,json,datetime,time,math,scipy.stats, collections;
import re

import numpy as np
import sklearn;
import scipy as sp;

from scipy.spatial import distance 
from scipy.stats import ranksums;


import pymongo;
from bson.objectid import ObjectId
from pymongo import MongoClient




configFile = json.load( open("./config.json") );
client = MongoClient(configFile["database_host"], int(configFile["database_port"]) );


databaseName=configFile["database_name"];

db = client[databaseName];

admin_password=configFile["admin_password"];

#print("success")

#print(databaseName)

def contrast(doc):

	cells1 = doc["A"]
	cells2 = doc["B"]
	sampleid = doc["C"]

	xlen = len(cells1);
	ylen = len(cells2);

	p=dict();
	n=dict();
	allexpr = db["expr_"+sampleid].find({},{"_id":1,"normalize":1});

	totallength = allexpr.count();
	each5step =  int(math.ceil(totallength/200)*10);

	currentperc = 0;

	index =0;
	for i in allexpr:

		index+=1;

		if index >= each5step:
			index = 0;
			currentperc+=5;
			if currentperc >=100:
				currentperc=99;
				
			db.contrastResult.update_one({"_id":doc["_id"] },{"$set":{"donePercent": currentperc } })



		g = i["_id"];
		expr = i["normalize"];
		x=[];
		y=[];

		xpos=0;
		ypos=0;

		for j in cells1:
			x.append(expr[j])
			if expr[j]>0:
				xpos+=1;


		for j in cells2:
			y.append(expr[j]);
			if expr[j]>0:
				ypos+=1;


		percx = xpos/xlen;
		percy = ypos/ylen;


		if abs(percx-percy) <  0.25:
			continue; 

		#ranksumsres = scipy.stats.ranksums(x,y);
		ranksumsres = scipy.stats.ranksums(x,y);
		statics = ranksumsres[0];
		pval = ranksumsres[1];
			
		if pval < 0.01:
			if statics >=0:
				p[g]=pval;
			else:
				n[g]=pval;



		
				

	p = sorted(p.items(), key=lambda kv: kv[1] );
	n =	sorted(n.items(), key=lambda kv: kv[1] );

	p2=[];
	n2=[];
	for i in p:
		p2.append(i[0]);
	p=None;
	for i in n:
		n2.append(i[0]);
	n=None;

	db.contrastResult.update_one({"_id":doc["_id"]},{"$set":{"donePercent": 100,"result":{"p":p2,"n":n2} } });
	

def main():

	contrastId = sys.argv[1];

	jobdoc = db.contrastResult.find_one({"_id":ObjectId(contrastId)},{"jobid":0});
	if jobdoc["job"] == "contrast":
		contrast(jobdoc);
		
	

main();